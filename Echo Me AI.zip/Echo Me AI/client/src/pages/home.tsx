import { useState, useEffect } from "react";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { AIGenerationRequest, AIGenerationResponse, AIError, MODE_TEMPLATES } from "@shared/types";

interface LoadingSpinnerProps {
  currentStep?: string;
  mode?: string;
  progress?: number;
  elapsedTime?: number;
}

const LoadingSpinner = ({ currentStep = 'processing', mode = 'movie', progress = 0, elapsedTime = 0 }: LoadingSpinnerProps) => {
  const [dots, setDots] = useState('');
  const [currentIcon, setCurrentIcon] = useState('🤖');
  const [pulseColor, setPulseColor] = useState('border-yellow-400');

  useEffect(() => {
    const interval = setInterval(() => {
      setDots(prev => prev.length >= 3 ? '' : prev + '.');
    }, 500);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    const icons = ['🤖', '✨', '🎭', '🎨', '💫'];
    const colors = ['border-yellow-400', 'border-blue-400', 'border-purple-400', 'border-green-400', 'border-pink-400'];
    let iconIndex = 0;
    const iconInterval = setInterval(() => {
      setCurrentIcon(icons[iconIndex]);
      setPulseColor(colors[iconIndex]);
      iconIndex = (iconIndex + 1) % icons.length;
    }, 800);
    return () => clearInterval(iconInterval);
  }, []);

  const getStepInfo = () => {
    switch(currentStep) {
      case 'processing': 
        return {
          text: 'Processing your thought',
          desc: 'Analyzing input and preparing AI context',
          color: 'text-blue-400'
        };
      case 'generating': 
        return {
          text: 'AI is creating content',
          desc: 'Gemini is crafting your creative content',
          color: 'text-purple-400'
        };
      case 'imaging': 
        return {
          text: 'Generating visual content',
          desc: 'Creating artistic visuals with Gemini Vision',
          color: 'text-green-400'
        };
      case 'finalizing': 
        return {
          text: 'Finalizing masterpiece',
          desc: 'Adding finishing touches and optimization',
          color: 'text-pink-400'
        };
      default: 
        return {
          text: 'Working on something amazing',
          desc: 'AI is processing your request',
          color: 'text-yellow-400'
        };
    }
  };

  const stepInfo = getStepInfo();
  const formatTime = (seconds: number) => {
    if (seconds < 60) return `${seconds}s`;
    return `${Math.floor(seconds / 60)}m ${seconds % 60}s`;
  };

  const getProgressSteps = () => {
    const steps = [
      { key: 'processing', label: 'Processing', icon: '🧠' },
      { key: 'generating', label: 'Creating', icon: '✍️' },
      { key: 'imaging', label: 'Visualizing', icon: '🎨' },
      { key: 'finalizing', label: 'Finalizing', icon: '✨' }
    ];
    
    return steps.map((step, index) => {
      const isActive = step.key === currentStep;
      const isCompleted = steps.findIndex(s => s.key === currentStep) > index;
      
      return (
        <div key={step.key} className="flex items-center">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm transition-all ${
            isActive ? 'bg-yellow-400 text-black animate-pulse' :
            isCompleted ? 'bg-green-400 text-black' :
            'bg-white/20 text-white/60'
          }`}>
            {isCompleted ? '✓' : step.icon}
          </div>
          <div className="ml-2 text-white/80 text-sm font-medium">
            {step.label}
          </div>
          {index < steps.length - 1 && (
            <div className={`w-8 h-0.5 mx-2 transition-all ${
              isCompleted ? 'bg-green-400' : 'bg-white/20'
            }`}></div>
          )}
        </div>
      );
    });
  };

  return (
    <div className="flex flex-col items-center justify-center py-12">
      {/* Main Spinner */}
      <div className="relative mb-6">
        <div className={`w-24 h-24 border-4 border-gray-200 rounded-full animate-spin ${pulseColor}`}></div>
        <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 text-4xl animate-pulse">
          {currentIcon}
        </div>
        {/* Progress Ring */}
        <svg className="absolute top-0 left-0 w-24 h-24 transform -rotate-90" viewBox="0 0 24 24">
          <circle
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="1"
            fill="none"
            className="text-white/20"
          />
          <circle
            cx="12"
            cy="12"
            r="10"
            stroke="currentColor"
            strokeWidth="1"
            fill="none"
            strokeDasharray={`${2 * Math.PI * 10}`}
            strokeDashoffset={`${2 * Math.PI * 10 * (1 - progress / 100)}`}
            className="text-yellow-400 transition-all duration-300"
          />
        </svg>
      </div>

      {/* Step Information */}
      <div className="text-center mb-6">
        <p className={`text-2xl font-bold mb-2 ${stepInfo.color}`}>
          {stepInfo.text}{dots}
        </p>
        <p className="text-white/70 text-sm mb-3">
          {stepInfo.desc}
        </p>
        <div className="flex justify-center items-center space-x-4 text-sm text-white/60">
          <div className="flex items-center">
            <div className="w-2 h-2 bg-yellow-400 rounded-full mr-2 animate-pulse"></div>
            {MODE_TEMPLATES[mode as keyof typeof MODE_TEMPLATES]?.responseFormat || 'Content'} Mode
          </div>
          {elapsedTime > 0 && (
            <>
              <div>•</div>
              <div>{formatTime(elapsedTime)} elapsed</div>
            </>
          )}
        </div>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center justify-center mb-6">
        {getProgressSteps()}
      </div>

      {/* Bouncing Dots */}
      <div className="flex justify-center space-x-2">
        <div className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce"></div>
        <div className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" style={{animationDelay: '0.1s'}}></div>
        <div className="w-2 h-2 bg-yellow-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
      </div>

      {/* Estimated Time */}
      <div className="mt-4 text-white/50 text-xs text-center">
        <div>Typical generation time: 8-15 seconds</div>
        <div className="mt-1">Creating high-quality AI content takes time</div>
      </div>
    </div>
  );
};

interface ResultCardProps {
  result: AIGenerationResponse;
  onTryAgain: () => void;
}

const ResultCard = ({ result, onTryAgain }: ResultCardProps) => {
  const { toast } = useToast();

  const handleCopyContent = async () => {
    try {
      await navigator.clipboard.writeText(result.content);
      toast({
        title: "Copied to clipboard!",
        description: "Content has been copied to your clipboard.",
      });
    } catch (err) {
      toast({
        title: "Copy failed",
        description: "Unable to copy content to clipboard.",
        variant: "destructive",
      });
    }
  };

  const handleShare = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      toast({
        title: "Link copied!",
        description: "Share link has been copied to your clipboard.",
      });
    } catch (err) {
      toast({
        title: "Share failed",
        description: "Unable to copy share link.",
        variant: "destructive",
      });
    }
  };

  const handleDownload = () => {
    if (result.imageUrl) {
      const link = document.createElement('a');
      link.href = result.imageUrl;
      link.download = `echome-${result.type}-${Date.now()}.jpg`;
      link.click();
    }
  };

  return (
    <div className="bg-white/20 backdrop-blur-lg rounded-2xl p-6 border border-white/30 shadow-2xl">
      <div className="text-center mb-6">
        <div className="flex items-center justify-center mb-3">
          <div className="bg-gradient-to-r from-green-400 to-blue-500 text-white px-3 py-1 rounded-full text-xs font-semibold mr-3">
            AI Generated
          </div>
          <div className="text-yellow-400 text-sm">
            ⚡ Powered by Google Gemini
          </div>
        </div>
        <h2 className="text-3xl font-bold text-yellow-400 mb-2 drop-shadow-lg">
          {result.title}
        </h2>
        <span className="bg-gradient-to-r from-yellow-400 to-orange-400 text-black px-4 py-2 rounded-full font-semibold text-sm shadow-lg">
          {result.type}
        </span>
      </div>
      
      <div className="grid md:grid-cols-2 gap-6 mb-6">
        <div className="bg-black/40 rounded-lg p-4 border border-white/20">
          <div className="flex items-center justify-between mb-3">
            <span className="text-white/80 text-sm font-medium">AI Response</span>
            <button 
              onClick={handleCopyContent}
              className="text-white/60 hover:text-white transition-colors"
              title="Copy to clipboard"
            >
              📋
            </button>
          </div>
          <pre className="text-white text-sm whitespace-pre-wrap leading-relaxed font-mono">
            {result.content}
          </pre>
          <div className="mt-3 text-xs text-white/40">
            Generated in {result.processingTime}ms
          </div>
        </div>
        
        <div className="flex justify-center">
          <div className="relative group">
            {result.imageUrl ? (
              <>
                <img
                  src={result.imageUrl}
                  alt={`AI generated visual for ${result.type}`}
                  className="rounded-lg shadow-2xl max-w-full h-auto transition-transform group-hover:scale-105 duration-300"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/20 to-transparent rounded-lg"></div>
                <div className="absolute bottom-2 right-2 bg-black/60 text-white px-2 py-1 rounded text-xs">
                  Gemini Vision
                </div>
              </>
            ) : (
              <div className="w-full h-64 bg-gradient-to-br from-purple-500 to-pink-500 rounded-lg flex items-center justify-center">
                <div className="text-white text-center">
                  <div className="text-4xl mb-2">🎨</div>
                  <div className="text-sm">Image generating...</div>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="bg-white/10 rounded-lg p-4 mb-6 border border-white/20">
        <h3 className="text-white font-semibold mb-2 flex items-center">
          <span className="mr-2">🧠</span>
          AI Insights
        </h3>
        <div className="grid md:grid-cols-3 gap-4 text-sm">
          <div className="text-center">
            <div className="text-yellow-400 font-semibold">{result.confidence}%</div>
            <div className="text-white/60">Confidence</div>
          </div>
          <div className="text-center">
            <div className="text-yellow-400 font-semibold">{result.creativity}</div>
            <div className="text-white/60">Creativity Level</div>
          </div>
          <div className="text-center">
            <div className="text-yellow-400 font-semibold">{result.mood}</div>
            <div className="text-white/60">Detected Mood</div>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap justify-center gap-4">
        <button
          onClick={handleShare}
          className="bg-green-500 hover:bg-green-600 text-white px-6 py-3 rounded-lg font-semibold transition-all hover:shadow-lg transform hover:scale-105"
        >
          📱 Share
        </button>
        <button
          onClick={handleDownload}
          className="bg-blue-500 hover:bg-blue-600 text-white px-6 py-3 rounded-lg font-semibold transition-all hover:shadow-lg transform hover:scale-105"
        >
          💾 Save
        </button>
        <button
          onClick={onTryAgain}
          className="bg-orange-500 hover:bg-orange-600 text-white px-6 py-3 rounded-lg font-semibold transition-all hover:shadow-lg transform hover:scale-105"
        >
          🔄 Try Again
        </button>
      </div>
    </div>
  );
};

interface SamplePromptsProps {
  onSelectPrompt: (prompt: string) => void;
  selectedMode: string;
}

const SamplePrompts = ({ onSelectPrompt, selectedMode }: SamplePromptsProps) => {
  const modeSpecificPrompts = {
    movie: [
      "I'm so tired I could sleep for a week",
      "I accidentally wore my shirt inside out all day",
      "I'm stressed about my deadline tomorrow",
      "I just got a promotion at work!",
      "I'm feeling lonely tonight"
    ],
    song: [
      "I love rainy days and hot coffee",
      "I can't stop laughing at my own jokes",
      "I miss being a kid with no responsibilities",
      "I'm eating pizza for breakfast and I don't care",
      "I just fell in love with my best friend"
    ],
    haiku: [
      "The morning sun through my window",
      "I'm grateful for small moments",
      "Autumn leaves falling silently",
      "Coffee steam rising slowly",
      "Night sounds in the city"
    ],
    roast: [
      "I think I'm really good at cooking",
      "I always lose my keys",
      "I talk to my plants like they're people",
      "I still don't know how to fold a fitted sheet",
      "I pretend to understand wine"
    ],
    joke: [
      "Why is adulting so complicated?",
      "I can't find anything in my own house",
      "I'm always running late",
      "I still count on my fingers",
      "I Google everything, even simple math"
    ]
  };

  const prompts = modeSpecificPrompts[selectedMode as keyof typeof modeSpecificPrompts] || modeSpecificPrompts.movie;

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20">
      <div className="text-center mb-4">
        <h3 className="text-white text-lg font-semibold mb-2">
          ✨ AI-Curated Prompts for {selectedMode.charAt(0).toUpperCase() + selectedMode.slice(1)} Mode
        </h3>
        <p className="text-white/70 text-sm">
          Try these carefully crafted prompts or type your own thoughts
        </p>
      </div>
      <div className="flex flex-wrap gap-2 justify-center">
        {prompts.map((prompt, index) => (
          <button
            key={index}
            onClick={() => onSelectPrompt(prompt)}
            className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-lg text-sm transition-all hover:shadow-lg transform hover:scale-105 border border-white/30 group"
          >
            <span className="group-hover:text-yellow-300 transition-colors">
              "{prompt}"
            </span>
          </button>
        ))}
      </div>
    </div>
  );
};

interface ModeSelectorProps {
  selectedMode: string;
  onModeChange: (mode: string) => void;
}

const ModeSelector = ({ selectedMode, onModeChange }: ModeSelectorProps) => {
  const modes = [
    { 
      id: 'movie', 
      icon: '🎬', 
      name: 'Movie Scene', 
      description: 'Epic dramatic scenes',
      aiModel: 'GPT-4 Turbo',
      features: ['Cinematic dialogue', 'Character development', 'Scene setting']
    },
    { 
      id: 'song', 
      icon: '🎤', 
      name: 'Theme Song', 
      description: 'Catchy musical numbers',
      aiModel: 'GPT-4 Creative',
      features: ['Verse/Chorus structure', 'Rhyme schemes', 'Musical style']
    },
    { 
      id: 'haiku', 
      icon: '🧠', 
      name: 'Haiku', 
      description: 'Zen poetry wisdom',
      aiModel: 'GPT-4 Poetic',
      features: ['5-7-5 syllables', 'Nature imagery', 'Emotional depth']
    },
    { 
      id: 'roast', 
      icon: '🔥', 
      name: 'Roast', 
      description: 'Playful teasing',
      aiModel: 'GPT-4 Comedy',
      features: ['Witty observations', 'Clever wordplay', 'Good-natured humor']
    },
    { 
      id: 'joke', 
      icon: '😂', 
      name: 'Joke', 
      description: 'Comedy gold',
      aiModel: 'GPT-4 Comedy',
      features: ['Perfect timing', 'Unexpected punchlines', 'Clean humor']
    }
  ];

  return (
    <div className="bg-white/10 backdrop-blur-lg rounded-2xl p-6 border border-white/20 mb-6">
      <h3 className="text-white text-lg font-semibold mb-4 text-center">
        🎭 Choose Your AI Entertainment Mode:
      </h3>
      <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
        {modes.map((mode) => (
          <button
            key={mode.id}
            onClick={() => onModeChange(mode.id)}
            className={`p-4 rounded-xl border-2 transition-all transform hover:scale-105 text-left ${
              selectedMode === mode.id
                ? 'border-yellow-400 bg-yellow-400/20 text-yellow-400'
                : 'border-white/30 bg-white/10 text-white hover:border-white/50'
            }`}
          >
            <div className="text-2xl mb-2">{mode.icon}</div>
            <div className="text-sm font-semibold mb-1">{mode.name}</div>
            <div className="text-xs opacity-80 mb-2">{mode.description}</div>
            <div className="text-xs opacity-60">
              <div className="font-medium">{mode.aiModel}</div>
              <div className="mt-1">
                {mode.features.map((feature, idx) => (
                  <div key={idx} className="truncate">• {feature}</div>
                ))}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
};

export default function Home() {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<AIGenerationResponse | null>(null);
  const [loading, setLoading] = useState(false);
  const [loadingStep, setLoadingStep] = useState('processing');
  const [progress, setProgress] = useState(0);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [showSamples, setShowSamples] = useState(true);
  const [selectedMode, setSelectedMode] = useState('movie');
  const [error, setError] = useState<AIError | null>(null);
  const [aiStats, setAiStats] = useState({
    totalGenerations: 0,
    favoriteMode: 'movie',
    avgResponseTime: 0
  });

  const { toast } = useToast();

  const generateMagic = async () => {
    if (!input.trim()) return;
    
    setLoading(true);
    setShowSamples(false);
    setError(null);
    setLoadingStep('processing');
    setProgress(0);
    setElapsedTime(0);

    // Start progress tracking
    const startTime = Date.now();
    const progressInterval = setInterval(() => {
      setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);

    // Simulate realistic progress steps
    const progressSteps = [
      { step: 'processing', delay: 500, progress: 10 },
      { step: 'generating', delay: 2000, progress: 40 },
      { step: 'imaging', delay: 6000, progress: 75 },
      { step: 'finalizing', delay: 1000, progress: 95 }
    ];

    const progressTimer = setTimeout(() => {
      let currentProgress = 0;
      progressSteps.forEach(({ step, delay, progress: stepProgress }, index) => {
        setTimeout(() => {
          setLoadingStep(step);
          setProgress(stepProgress);
          currentProgress = stepProgress;
        }, delay * index);
      });
    }, 100);

    try {
      const response = await apiRequest('POST', '/api/echome', {
        input,
        mode: selectedMode
      } as AIGenerationRequest);

      if (!response.ok) {
        throw new Error('Network error');
      }

      const data: AIGenerationResponse = await response.json();
      
      // Complete progress
      setProgress(100);
      setLoadingStep('finalizing');
      
      setTimeout(() => {
        setResult(data);
        setAiStats(prev => ({
          totalGenerations: prev.totalGenerations + 1,
          favoriteMode: selectedMode,
          avgResponseTime: Math.round((prev.avgResponseTime + data.processingTime) / 2)
        }));

        toast({
          title: "Magic created!",
          description: `Your ${selectedMode} has been generated successfully.`,
        });
      }, 500);

    } catch (err) {
      console.error('Generation error:', err);
      setError({
        type: "AI Error",
        title: "Something went wrong!",
        message: "Our AI is having a moment. Please try again.",
        code: 'GENERATION_ERROR'
      });
      
      toast({
        title: "Generation failed",
        description: "Unable to generate content. Please try again.",
        variant: "destructive",
      });
    } finally {
      clearInterval(progressInterval);
      clearTimeout(progressTimer);
      setTimeout(() => {
        setLoading(false);
        setLoadingStep('processing');
        setProgress(0);
        setElapsedTime(0);
      }, 1000);
    }
  };

  const handleTryAgain = () => {
    setResult(null);
    setError(null);
    setInput('');
    setShowSamples(true);
  };

  const handleSelectPrompt = (prompt: string) => {
    setInput(prompt);
    setShowSamples(false);
  };

  const handleModeChange = (mode: string) => {
    setSelectedMode(mode);
    setResult(null);
    setError(null);
    if (input) {
      setShowSamples(false);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      generateMagic();
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-600 via-pink-600 to-orange-500 p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-2 drop-shadow-2xl">
            EchoMe
            <span className="text-yellow-400 ml-2">AI</span>
          </h1>
          <p className="text-lg md:text-xl text-white/90 drop-shadow-lg mb-2">
            Turn any thought into entertainment magic with AI ✨
          </p>
          <div className="flex justify-center items-center space-x-4 text-sm text-white/70">
            <div>🤖 Powered by Google Gemini</div>
            <div>•</div>
            <div>🎨 Gemini Vision</div>
            <div>•</div>
            <div>{aiStats.totalGenerations} Generations</div>
          </div>
        </div>

        {/* Mode Selector */}
        <ModeSelector selectedMode={selectedMode} onModeChange={handleModeChange} />

        {/* Input Section */}
        <div className="bg-white/20 backdrop-blur-lg rounded-2xl p-6 mb-6 border border-white/30 shadow-2xl">
          <div className="flex items-center mb-4">
            <div className="text-white font-semibold">💭 Share your thought:</div>
            <div className="ml-auto text-white/60 text-sm">
              {input.length}/150 characters
            </div>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="What's on your mind? (e.g., 'I'm eating cereal for dinner again')"
            className="w-full h-24 bg-white/20 border-2 border-white/30 rounded-lg p-4 text-white placeholder-white/60 focus:border-yellow-400 focus:outline-none text-lg resize-none"
            maxLength={150}
            disabled={loading}
          />
          <div className="flex justify-between items-center mt-4">
            <div className="text-white/60 text-sm">
              AI will create a {selectedMode} based on your input
            </div>
            <button
              onClick={generateMagic}
              disabled={!input.trim() || loading}
              className="bg-gradient-to-r from-yellow-400 to-orange-400 hover:from-yellow-500 hover:to-orange-500 text-black font-bold py-3 px-8 rounded-lg transform transition-all hover:scale-105 disabled:opacity-50 disabled:cursor-not-allowed disabled:hover:scale-100 shadow-lg"
            >
              {loading ? 'AI Working...' : '✨ Generate Magic'}
            </button>
          </div>
        </div>

        {/* Sample Prompts */}
        {showSamples && !result && !loading && (
          <div className="mb-6">
            <SamplePrompts 
              onSelectPrompt={handleSelectPrompt} 
              selectedMode={selectedMode}
            />
          </div>
        )}

        {/* Loading State */}
        {loading && (
          <LoadingSpinner 
            currentStep={loadingStep} 
            mode={selectedMode}
            progress={progress}
            elapsedTime={elapsedTime}
          />
        )}

        {/* Error Display */}
        {error && (
          <div className="bg-red-500/20 backdrop-blur-lg rounded-2xl p-6 border border-red-500/30 text-center mb-6">
            <div className="text-red-400 text-4xl mb-4">🚨</div>
            <h2 className="text-red-400 text-xl font-semibold mb-2">{error.title}</h2>
            <p className="text-white/80 mb-4">{error.message}</p>
            <div className="text-white/60 text-sm mb-4">
              Error Code: {error.code}
            </div>
            <button 
              onClick={handleTryAgain}
              className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg font-semibold transition-colors"
            >
              Try Again
            </button>
          </div>
        )}

        {/* Result Display */}
        {result && !loading && (
          <ResultCard 
            result={result} 
            onTryAgain={handleTryAgain}
          />
        )}

        {/* Footer */}
        <div className="text-center mt-12 text-white/60 text-sm">
          <p>Built with ❤️ using OpenAI GPT-4 and DALL-E 3</p>
          <p className="mt-2">
            Your privacy matters - we don't store your inputs or generated content
          </p>
        </div>
      </div>
    </div>
  );
}
